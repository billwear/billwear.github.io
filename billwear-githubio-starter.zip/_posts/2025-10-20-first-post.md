---
layout: default
title: first post
---

this is a sample post. change it, delete it, write your own.

- markdown in, html out
- the `permalink` style is set in `_config.yml`
