---
layout: default
title: home
---

# start simple. see everything.

this is a minimal site with no theme and no magic. you control the html, css, and structure.

- edit `_layouts/default.html` to change the chrome
- edit `assets/css/main.css` to change the look
- edit this `index.md` to change the home content

want a post? there is a sample: [_first post_](/blog/first-post/).
