---
layout: default
title: about
permalink: /about/
---

# about

plain pages. plain css. fast and understandable.

use this page to state the mission. keep it short.
